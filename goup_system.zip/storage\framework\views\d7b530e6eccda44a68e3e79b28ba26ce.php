<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

    <div class="row">
        <div class="col-md-4">
            <!-- Foto de Perfil -->
            <div class="card">
                <div class="card-body text-center">

                    <img src="<?php echo e($user->foto_perfil ? asset('storage/' . $user->foto_perfil) : asset('imagens/default-avatar.png')); ?>"
                        alt="Foto de perfil" width="183" height="183" class="rounded-circle img-fluid ">

                    <h4 class="mt-3"><?php echo e($user->name); ?></h4>

                    <p><?php echo e($holding->nome); ?></p>

                    <!-- Último Acesso -->
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-hover mt-3">
                            <tbody>
                                <tr>
                                    <td>
                                        <strong>Último Acesso:</strong>
                                    </td>
                                    <td>
                                        <?php if($user->last_login_at): ?>
                                            <?php echo e($user->last_login_at->diffForHumans()); ?>

                                        <?php else: ?>
                                            Nunca logado
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <!-- Informações do Usuário -->
            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-2">
                        <div>
                            <h4 class="fw-bold mb-3">Dados Usuário</h4>
                        </div>
                        <!-- botao -->
                        <div class="ms-md-auto py-2 py-md-0">
                            <div class="btn-group" role="group" aria-label="Basic example">
                                <form action="<?php echo e(route('holdings.usuario.destroy', ['usuario' => $user->id])); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-secondary btn-sm" title="Excluir Produto"
                                        onclick="return confirm('Deseja excluir o item permanentemente?')"><i
                                            class="fa-solid fa-trash"></i></button>
                                </form>
                            </div>
                        </div>
                        <!-- botao -->
                    </div>
                </div>
                <div class="card-body">
                    <form>
                        <div class="row">
                            <div class="form-group col-md-8">
                                <label>Nome Completo </label>
                                <input type="text" class="form-control" id="nome_completo"
                                    value="<?php echo e($user->nome_completo); ?>"readonly>
                            </div>

                            <div class="form-group col-md-4">
                                <label>CPF </label>
                                <input type="text" name="cpf" class="form-control" id="cpf"
                                    value="<?php echo e($user->cpf); ?>" readonly>
                            </div>

                            <div class="form-group col-md-3">
                                <label>Data de Nascimento </label>
                                <input type="text" name="nascimento" class="form-control" id="data_nascimento"
                                    value="<?php echo e($user->data_nascimento); ?>" readonly>
                            </div>

                            <div class="form-group col-md-3">
                                <label>Telefone </label>
                                <input type="text" name="telefone" class="form-control" id="telefone"
                                    value="<?php echo e($user->telefone); ?>" readonly>
                            </div>
                            <div class="form-group col-md-6">
                                <label>E-mail </label>
                                <input type="email" class="form-control" id="email" value="<?php echo e($user->email); ?>"
                                    readonly>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>Cargo/Função </label>
                                <input type="text" name="cargo" class="form-control" id="cargo"
                                    value="<?php echo e($user->cargo); ?>" readonly>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Departamento </label>
                                <input type="text" name="departamento" class="form-control" id="departamento"
                                    value="<?php echo e($user->departamento); ?>" readonly>
                            </div>

                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <h4> Informações de Acesso ao Sistema </h4>
                                <hr />
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>Nome de Usuário </label>
                                <input type="text" class="form-control" id="name"
                                    value="<?php echo e($user->name); ?>"readonly>
                            </div>

                            <div class="form-group col-md-6">
                                <label>Senha </label>
                                <input type="password" name="password" id="password" value="<?php echo e(old('name')); ?>"
                                    class="form-control">
                            </div>

                            <div class="form-group col-md-3">
                                <label>Nível de Acesso</label>
                                <select class="form-select" aria-label="Default select example">
                                    <option value="1">Administrador</option>
                                    <option value="2"> Contador</option>
                                    <option value="3">Usuário</option>
                                    <option value="3">Padrão</option>
                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label>Status da Conta</label>
                                <select class="form-select" aria-label="Default select example">
                                    <option value="1">Ativo</option>
                                    <option value="2"> Inativor</option>
                                </select>
                            </div>
                        </div>








                    </form>

                    <div class="row pt-4">
                        <div class="col-md-12">
                            <div class="text-center">
                                <div class="btn-group" role="group" aria-label="Basic example">
                                    <a href="<?php echo e(route('holdings.usuario.edit', ['usuario' => $user->id])); ?>">
                                        <button class="btn btn-secondary">Editar Perfil</button>
                                    </a>
                                </div>
                                <div class="btn-group" role="group" aria-label="Basic example">
                                    <a href="<?php echo e(route('holdings.usuario.edit-password', ['usuario' => $user->id])); ?>">
                                        <button class="btn btn-secondary">Alterar Senha</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('holdings.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goup_system\resources\views\holdings\usuario\show.blade.php ENDPATH**/ ?>