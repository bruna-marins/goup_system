

<?php $__env->startSection('content'); ?>

    <div class="container">
        <h2 class="text-center">Tarefas do Dia: <?php echo e(\Carbon\Carbon::parse($data)->format('d/m/Y')); ?></h2>

        <!-- Exibe as tarefas do dia -->
        <?php if($tarefas->isEmpty()): ?>
            <p>Nenhuma tarefa cadastrada para este dia.</p>
        <?php else: ?>
            <ul>
                <?php $__currentLoopData = $tarefas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarefa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($tarefa->hora); ?> - <?php echo e($tarefa->titulo); ?>: <?php echo e($tarefa->descricao); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('empresas.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goup_system\resources\views\empresas\tarefa\show.blade.php ENDPATH**/ ?>