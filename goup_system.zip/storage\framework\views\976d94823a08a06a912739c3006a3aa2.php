<?php $__env->startSection('content'); ?>

    <!-- COnteudo -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-lg-12">
                        <!--Inserir o COnteudo da página -->
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <h3> Detalhes da Holding - <strong> <?php echo e($holding->nome); ?>  </strong></h3> <hr />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <p><strong>Nome Fantasia:</strong><br /> <?php echo e($holding->nome_fantasia); ?> </p>
                                    <p><strong>Inscrição Municipal:</strong><br /> <?php echo e($holding->inscricao_municipal); ?> </p>                               
                                </div>
                                <div class="col-md-4">
                                    <p><strong>CNPJ:</strong><br /> <?php echo e($holding->cnpj); ?> </p>
                                    <p><strong>Site:</strong><br /> <?php echo e($holding->email); ?> </p>
                                </div>
                                <div class="col-md-4">
                                    <p><strong>Data Abertura:</strong><br /> <?php echo e($holding->data_abertura); ?> </p>
                                    <p><strong>Natureza Jurídica:</strong><br /> <?php echo e($holding->natureza_juridica); ?> </p>
                                </div>
                            </div>

                            <div class="row pt-3">
                                <div class="form-group col-md-12">
                                    <h4>Informações Financeiras e Fiscais</h4> <hr />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <p><strong>Regime Tributário:</strong><br /> <?php echo e($holding->regime_tributario); ?> </p>
                                    <p><strong>Faturamento Anual:</strong><br /> <?php echo e($holding->faturamento_anual); ?> </p>
                                    <p><strong>Código de Tributação:</strong><br /> <?php echo e($holding->codigo_tributacao); ?> </p>
                                </div>
                                <div class="col-md-4">
                                    <p><strong>CNAE:</strong><br /> <?php echo e($holding->cnae); ?> </p>
                                    <p><strong>Responsável Contábil:</strong><br /> <?php echo e($holding->responsavel_contabil); ?> </p>
                                    <p><strong>Alíquotas Fiscais:</strong><br /> <?php echo e($holding->aliquota_fiscais); ?> </p>
                                </div>
                                <div class="col-md-4">
                                    <p><strong>Capital Social:</strong><br /> <?php echo e($holding->capital_social); ?> </p>
                                    <p><strong>Cargo/Função:</strong><br /> <?php echo e($holding->cargo); ?> </p>
                                </div>
                            </div>

                            <div class="row pt-3">
                                <div class="form-group col-md-12">
                                    <h4>Contato</h4> <hr />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <p><strong>Telefone:</strong><br /> <?php echo e($holding->telefone); ?> </p>
                                </div>
                                <div class="col-md-4">
                                    <p><strong>E-mail:</strong><br /> <?php echo e($holding->email); ?> </p>
                                </div>
                                <div class="col-md-4">
                                    <p><strong>Site:</strong><br /> <?php echo e($holding->site); ?> </p>
                                </div>
                            </div>

                            <div class="row pt-3">
                                <div class="form-group col-md-12">
                                    <h4>Endereço</h4> <hr />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <p><strong>CEP:</strong><br /> <?php echo e($holding->cep); ?> </p>
                                    <p><strong>Bairro:</strong><br /> <?php echo e($holding->bairro); ?> </p>
                                    <p><strong>Logradouro:</strong><br /> <?php echo e($holding->logradouro); ?> </p>

                                </div>
                                <div class="col-md-4">
                                    <p><strong>Estado:</strong><br /> <?php echo e($holding->estado); ?> </p>
                                    <p><strong>Cidade:</strong><br /> <?php echo e($holding->cidade); ?> </p>
                                    <p><strong>Número:</strong><br /> <?php echo e($holding->numero); ?> </p>
                                </div>
                                <div class="col-md-4">
                                    <p><strong>Complemento:</strong><br /> <?php echo e($holding->complemento); ?> </p>                               
                                </div>
                            </div>

                            <div class="row pt-3">
                                <div class="form-group col-md-12">
                                    <h4>Dados Sócio ou Proprietário</h4> <hr />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <p><strong>Sócio/Proprietário:</strong><br /> <?php echo e($holding->socio); ?> </p>
                                    <p><strong>CPF:</strong><br /> <?php echo e($holding->cpf); ?> </p>
                                </div>
                                <div class="col-md-4">
                                    <p><strong>Participação Societária:</strong><br /> <?php echo e($holding->participacao_societaria); ?> </p>
                                </div>
                                <div class="col-md-4">
                                    <p><strong>Cargo/Função:</strong><br /> <?php echo e($holding->cargo); ?> </p>                               
                                </div>
                            </div>
                        <!--Inserir o COnteudo da página -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- COnteudo -->

    <!-- Cabeçalho -->
    <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-4 pb-3">
        <div>
            <h3 class="fw-bold mb-3">Empresas cadastradas - <strong> <?php echo e($holding->nome); ?>  </strong></h3>
        </div>
    </div>
    <!-- Cabeçalho -->

    <!-- COnteudo -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-lg-12">
                        <!--Inserir o COnteudo da página -->
                            <!-- Verificar se há empresas cadastradas -->
                            <?php if($holding->empresas->isEmpty()): ?>
                                <!-- alerta -->
                                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    <p class="card-description">
                                        Não há empresas cadastradas nesta holding.
                                    </p>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                                <!-- alerta -->
                            <?php else: ?>

                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover mt-3">
                                    <thead class="table-dark">
                                        <tr>
                                            <th class="ms-5">ID</th>
                                            <th>Empresa</th>
                                            <th>CNPJ</th>
                                            <th>Endereço</th>
                                            <th>Telefone</th>
                                            <th style="width: 100px;">Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $holding->empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                            <tr>
                                                <td><?php echo e($empresa->id); ?></td>
                                                <td><?php echo e($empresa->nome); ?></td>
                                                <td><?php echo e($empresa->cnpj); ?></td>
                                                <td><?php echo e($empresa->endereco); ?></td>
                                                <td><?php echo e($empresa->telefone); ?></td>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <a href="<?php echo e(route('holdings.holding.show-empresa', ['holding' => $holding->id, 'empresa' => $empresa->id])); ?>"
                                                            class="btn btn-secondary btn-sm btn-icon-text  me-3"
                                                            title="Detalhes">
                                                            <i class="fa-regular fa-eye"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                            </div>
                        <!--Inserir o COnteudo da página -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('holdings.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goup_system\resources\views\holdings\holding\show.blade.php ENDPATH**/ ?>