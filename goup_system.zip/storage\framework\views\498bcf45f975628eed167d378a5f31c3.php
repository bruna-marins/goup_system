<div>
    <!-- It is quality rather than quantity that matters. - Lucius Annaeus Seneca -->
</div>
<?php /**PATH C:\xampp\htdocs\goup_system\resources\views\empresas\cliente\edit.blade.php ENDPATH**/ ?>