<?php $__env->startSection('content'); ?>
    <!-- Cabeçalho -->
    <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-2 pb-4">
        <div>
            <h3 class="fw-bold mb-3">Cadastrar nova Holding</h3>
        </div>
    </div>
    <!-- Cabeçalho -->

    <!-- COnteudo -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 col-lg-12">

                            <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

                            <!--Inserir o COnteudo da página -->
                            <form class="forms-sample" action="<?php echo e(route('holdings.holding.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <h4> Informações da Empresa </h4>
                                        <hr />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label>Nome da Holding</label>
                                            <input type="text" name="nome" id="nome" value="<?php echo e(old('nome')); ?>"
                                                class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-5">
                                        <div class="form-group">
                                            <label>Nome Fantasia</label>
                                            <input type="text" name="nome_fantasia" id="nome_fantasia"
                                                value="<?php echo e(old('nome_fantasia')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Data de Abertura</label>
                                            <input type="date" name="data_abertura" id="data_abertura"
                                                value="<?php echo e(old('data_abertura')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>CNPJ</label>
                                            <input type="text" name="cnpj" id="cnpj" value="<?php echo e(old('cnpj')); ?>"
                                                class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Inscrição Municipal</label>
                                            <input type="text" name="inscricao_municipal" id="inscricao_municipal"
                                                value="<?php echo e(old('inscricao_municipal')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Natureza Jurídica</label>
                                            <select class="form-control" id="natureza_juridica" name="natureza_juridica">
                                                <option value="MEI"
                                                    <?php echo e(old('natureza_juridica', $empresa->natureza_juridica ?? '') == 'MEI' ? 'selected' : ''); ?>>
                                                    MEI
                                                </option>
                                                <option value="EI"
                                                    <?php echo e(old('natureza_juridica', $empresa->natureza_juridica ?? '') == 'EI' ? 'selected' : ''); ?>>
                                                    EI
                                                </option>
                                                <option value="Ltda."
                                                    <?php echo e(old('natureza_juridica', $empresa->natureza_juridica ?? '') == 'Ltda.' ? 'selected' : ''); ?>>
                                                    Ltda.
                                                </option>
                                                <option value="SS"
                                                    <?php echo e(old('natureza_juridica', $empresa->natureza_juridica ?? '') == 'SS' ? 'selected' : ''); ?>>
                                                    SS
                                                </option>
                                                <option value="SA"
                                                    <?php echo e(old('natureza_juridica', $empresa->natureza_juridica ?? '') == 'SA' ? 'selected' : ''); ?>>
                                                    SA
                                                </option>
                                                <option value="SLU"
                                                    <?php echo e(old('natureza_juridica', $empresa->natureza_juridica ?? '') == 'SLU' ? 'selected' : ''); ?>>
                                                    SLU
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <h4> Endereço </h4>
                                        <hr />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>CEP</label>
                                            <input type="text" name="cep" id="cep"
                                                value="<?php echo e(old('cep')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Estado</label>
                                            <input type="text" name="estado" id="estado" value="<?php echo e(old('estado')); ?>"
                                                class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Cidade</label>
                                            <input type="text" name="cidade" id="cidade"
                                                value="<?php echo e(old('cidade')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Bairro</label>
                                            <input type="text" name="bairro" id="bairro" value="<?php echo e(old('bairro')); ?>"
                                                class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Logradouro</label>
                                            <input type="text" name="logradouro" id="logradouro" value="<?php echo e(old('logradouro')); ?>"
                                                class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label>Número</label>
                                            <input type="text" name="numero" id="numero" value="<?php echo e(old('numero')); ?>"
                                                class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Complemento <small>(Opcional)</small> </label>
                                            <input type="text" name="complemento" id="complemento"
                                                value="<?php echo e(old('complemento')); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <h4> Contato </h4>
                                        <hr />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Telefone</label>
                                            <input type="text" name="telefone" id="telefone"
                                                value="<?php echo e(old('telefone')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>E-mail Corporativo</label>
                                            <input type="text" name="email" id="email"
                                                value="<?php echo e(old('email')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Site</label>
                                            <input type="text" name="site" id="site"
                                                value="<?php echo e(old('site')); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <h4> Informações Financeiras e Fiscais </h4>
                                        <hr />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Regime Tributário</label>
                                            <select class="form-control" id="regime_tributario" name="regime_tributario">
                                                <option value="Simples Nacional"
                                                    <?php echo e(old('regime_tributario', $empresa->regime_tributario ?? '') == 'Simples Nacional' ? 'selected' : ''); ?>>
                                                    Simples Nacional
                                                </option>
                                                <option value="Lucro Presumido"
                                                    <?php echo e(old('regime_tributario', $empresa->regime_tributario ?? '') == 'Lucro Presumido' ? 'selected' : ''); ?>>
                                                    Lucro Presumido
                                                </option>
                                                <option value="Lucro Real"
                                                    <?php echo e(old('regime_tributario', $empresa->regime_tributario ?? '') == 'Lucro Real' ? 'selected' : ''); ?>>
                                                    Lucro Real
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>CNAE</label>
                                            <input type="text" name="cnae" id="cnae"
                                                value="<?php echo e(old('cnae')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Capital Social</label>
                                            <input type="text" name="capital_social" id="capital_social"
                                                value="<?php echo e(old('capital_social')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Faturamento Anual</label>
                                            <input type="text" name="faturamento_anual" id="faturamento_anual"
                                                value="<?php echo e(old('faturamento_anual')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Responsável Contábil</label>
                                            <input type="text" name="responsavel_contabil" id="responsavel_contabil"
                                                value="<?php echo e(old('responsavel_contabil')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Código de Tributação</label>
                                            <input type="text" name="codigo_tributacao" id="codigo_tributacao"
                                                value="<?php echo e(old('codigo_tributacao')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Alíquotas Fiscais</label>
                                            <input type="text" name="aliquota_fiscais" id="aliquota_fiscais"
                                                value="<?php echo e(old('aliquota_fiscais')); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <h4> Dados de Sócios ou Proprietários </h4>
                                        <hr/>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Nome do Sócio/Proprietário</label>
                                            <input type="text" name="socio" id="socio"
                                                value="<?php echo e(old('socio')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>CPF</label>
                                            <input type="text" name="cpf" id="cpf"
                                                value="<?php echo e(old('cpf')); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Participação Societária</label>
                                            <input type="text" name="participacao_societaria"
                                                id="participacao_societaria" value="<?php echo e(old('participacao_societaria')); ?>"
                                                class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Cargo/Função</label>
                                            <input type="text" name="cargo" id="cargo"
                                                value="<?php echo e(old('cargo')); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <div class="row pt-4">
                                    <div class="col-md-12">
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-secondary">Cadastrar</button>
                                            <button type="reset" class="btn btn-secondary">Cancelar</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <!--Inserir o COnteudo da página -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('holdings.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goup_system\resources\views\holdings\holding\create.blade.php ENDPATH**/ ?>