<?php $__env->startSection('content'); ?>
    <!-- Cabeçalho -->
    <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-2 pb-4">
        <div>
            <h3 class="fw-bold mb-3">Cadastrar Novo Usuário</h3>
        </div>
        <!-- botao -->
        <div class="ms-md-auto py-2 py-md-0">
            <div class="btn-group" role="group" aria-label="Basic example">
                <a href="<?php echo e(route('holdings.usuario.index')); ?>" class="btn btn btn-secondary btn-sm" title="Listar Usuários">
                    <i class="fa-solid fa-list"></i>
                </a>
            </div>
        </div>
        <!-- botao -->
    </div>
    <!-- Cabeçalho -->

    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>

    <!-- COnteudo -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <!--Inserir o COnteudo da página -->
                    <form action="<?php echo e(route('holdings.usuario.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>

                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>Nome Completo </label>
                                <input type="text" name="nome_completo" id="nome_completo" value="<?php echo e(old('nome_completo')); ?>"
                                    class="form-control">
                            </div>

                            <div class="form-group col-md-2">
                                <label>CPF </label>
                                <input type="text" name="cpf" id="cpf" value="<?php echo e(old('cpf')); ?>"
                                    class="form-control">
                            </div>
                        
                            <div class="form-group col-md-2">
                                <label>Data de Nascimento </label>
                                <input type="date" name="data_nascimento" id="data_nascimento" value="<?php echo e(old('data_nascimento')); ?>"
                                    class="form-control">
                            </div>

                            <div class="form-group col-md-2">
                                <label>Telefone </label>
                                <input type="text" name="telefone" id="telefone" value="<?php echo e(old('telefone')); ?>"
                                    class="form-control">
                            </div>

                            <div class="form-group col-md-4">
                                <label>E-mail </label>
                                <input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>"
                                    class="form-control">
                            </div>                            
                        
                            <div class="form-group col-md-4">
                                <label>Cargo/Função </label>
                                <input type="text" name="cargo" id="cargo" value="<?php echo e(old('cargo')); ?>"
                                    class="form-control">
                            </div>
                            <div class="form-group col-md-4">
                                <label>Departamento </label>
                                <input type="text" name="departamento" id="departamento" value="<?php echo e(old('departamento')); ?>"
                                    class="form-control">
                            </div>                                                        
                        </div>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <h4> Informações de Acesso ao Sistema </h4> <hr />
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-3">
                                <label>Nome de Usuário </label>
                                <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>"
                                    class="form-control">
                            </div>
                        
                            <div class="form-group col-md-3">
                                <label>Senha </label>
                                <input type="password" name="password" id="password" value="<?php echo e(old('password')); ?>"
                                    class="form-control">
                            </div>

                            <div class="form-group col-md-3">
                                <label>Nível de Acesso</label>
                                <select class="form-select" aria-label="Default select example">
                                    <option value="1">Administrador</option>
                                    <option value="2"> Contador</option>
                                    <option value="3">Usuário</option>
                                    <option value="3">Padrão</option>                                    
                                </select>
                            </div> 
                            <div class="form-group col-md-3">
                                <label>Status da Conta</label>
                                <select name="status" id="status" class="form-select" aria-label="Default select example">
                                    <option value="0" <?php echo e($usuario->status ? 'selected' : ''); ?>>Inativo</option>
                                    <option value="1" <?php echo e($usuario->status ? 'selected' : ''); ?>>Ativo</option>                                  
                                </select>
                            </div>                                                         
                        </div>

                        <div class="row pt-4">
                            <div class="col-md-12">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-secondary">Cadastrar</button>
                                    <button type="reset" class="btn btn-secondary">Cancelar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!--Inserir o COnteudo da página -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('holdings.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goup_system\resources\views\holdings\usuario\create.blade.php ENDPATH**/ ?>