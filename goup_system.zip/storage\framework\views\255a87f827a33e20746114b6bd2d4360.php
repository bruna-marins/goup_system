

<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
    
    <h1>Editar Foto Perfil</h1>

    <form action="<?php echo e(route('empresas.profile.update-foto')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Exibir a foto de perfil ou uma imagem genérica -->
        <div>
            <img src="<?php echo e($user->foto_perfil ? asset('storage/' . $user->foto_perfil) : asset('imagens/default-avatar.png')); ?>"
                alt="Foto de perfil" width="150" height="150">
        </div>

        <!-- Campo para upload da foto -->
        <div class="form-group">
            <label for="foto_perfil">Alterar foto de perfil:</label>
            <input type="file" class="form-control" name="foto_perfil" id="foto_perfil">
        </div>

        <button type="submit" class="btn btn-primary">Atualizar Foto</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('empresas.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goup_system\resources\views\empresas\profile\edit-foto.blade.php ENDPATH**/ ?>