

<?php $__env->startSection('content'); ?>

    <div class="container">
        <h2 class="text-center">Adicionar Tarefa Dia: <?php echo e(\Carbon\Carbon::parse($data)->format('d/m/Y')); ?></h2>

        <!-- Formulário para adicionar tarefa -->
        <form action="<?php echo e(route('empresas.tarefa.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="data" value="<?php echo e($data); ?>">

            <div class="mb-3">
                <label for="titulo" class="form-label">Título da Tarefa</label>
                <input type="text" class="form-control" id="titulo" name="titulo" required>
            </div>

            <div class="mb-3">
                <label for="descricao" class="form-label">Descrição</label>
                <textarea class="form-control" id="descricao" name="descricao"></textarea>
            </div>

            <div class="mb-3">
                <label for="hora" class="form-label">Hora</label>
                <input type="time" class="form-control" id="hora" name="hora" required>
            </div>

            <button type="submit" class="btn btn-primary">Adicionar Tarefa</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('empresas.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goup_system\resources\views\empresas\tarefa\create.blade.php ENDPATH**/ ?>