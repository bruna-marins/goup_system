<?php $__env->startSection('content'); ?>

<!-- Cabeçalho -->
<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-2 pb-4">
    <div>
        <h3 class="fw-bold mb-3">Lista de Holdings</h3>
    </div>
    <!-- botao -->
    <div class="ms-md-auto py-2 py-md-0">
        <div class="btn-group" role="group" aria-label="Basic example">
            <a href="<?php echo e(route('holdings.holding.create')); ?>" class="btn btn btn-secondary btn-sm" title="Cadastrar Nova Holding">
                <i class="fa-solid fa-plus"></i>
            </a>
        </div>
    </div>
    <!-- botao -->
</div>
<!-- Cabeçalho -->

<!-- COnteudo -->
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12 col-lg-12">
                    <!--Inserir o COnteudo da página -->
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover mt-3">
                                <thead class="table-dark">
                                    <tr>
                                        <th class="ms-5">ID</th>
                                        <th>Empresa</th>
                                        <th>CNPJ</th>
                                        <th>Endereço</th>
                                        <th>Telefone</th>
                                        <th style="width: 100px;">Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $holdings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($holding->id); ?></td>
                                            <td><?php echo e($holding->nome); ?></td>
                                            <td><?php echo e($holding->cnpj); ?></td>
                                            <td><?php echo e($holding->endereco); ?></td>
                                            <td><?php echo e($holding->telefone); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <a href="<?php echo e(route('holdings.holding.edit', $holding->id)); ?>" class="btn  btn-secondary btn-sm btn-icon-text me-3" title="Editar Holding">
                                                        <i class="fa-solid fa-edit btn-icon-append"></i>                          
                                                    </a>
                                                    <a href="<?php echo e(route('holdings.holding.show', $holding->id)); ?>" class="btn  btn-secondary btn-sm btn-icon-text  me-3" title="Detalhes">
                                                        <i class="fa-regular fa-eye"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('holdings.holding.pdf-dados', $holding->id)); ?>" class="btn  btn-secondary btn-sm btn-icon-text  me-3" title="Gerar pdf">
                                                        <i class="fa-regular fa-file"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <p>Nenhuma Empresa Encontrada</p>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!--tabela -->
                    <!--Inserir o COnteudo da página -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



 
    

        

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('holdings.layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goup_system\resources\views\holdings\holding\index.blade.php ENDPATH**/ ?>