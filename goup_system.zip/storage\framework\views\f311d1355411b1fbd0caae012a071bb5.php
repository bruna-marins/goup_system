<div>
    <!-- I begin to speak only when I am certain what I will say is not better left unsaid. - Cato the Younger -->
</div>
<?php /**PATH C:\xampp\htdocs\goup_system\resources\views\empresas\cliente\show.blade.php ENDPATH**/ ?>